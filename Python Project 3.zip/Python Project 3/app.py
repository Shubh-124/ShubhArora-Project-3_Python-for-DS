import os
from config import SECRET_KEY

# import secrets
# secret_key = secrets.token_hex(16)
# print(secret_key)

from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import yaml
import pickle

app = Flask(__name__)

# Configuring MySQL
db = yaml.safe_load(open('db.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']
mysql = MySQL(app)

# Secret key for session management
app.secret_key = SECRET_KEY

# redirect('home.html')


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        userDetails = request.form
        username = userDetails['username']
        password = userDetails['password']
        cur = mysql.connection.cursor()
        cur.execute(
            "INSERT INTO user(username, password) VALUES(%s, %s)", (username, password))
        mysql.connection.commit()
        cur.close()
        return redirect('/login')
    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        userDetails = request.form
        username = userDetails['username']
        password = userDetails['password']
        cur = mysql.connection.cursor()
        result = cur.execute(
            "SELECT * FROM user WHERE username = %s AND password = %s", (username, password))
        if result > 0:
            session['username'] = username
            return redirect(url_for('enter_details'))
        else:
            return 'Username or Password is incorrect'
    return render_template('login.html')


@app.route('/enter_details')
def enter_details():
    return render_template('predict.html')


@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        details = request.form
        # Assuming you are retrieving the features here to pass to the model
        features = [
            int(details['gender']),
            int(details['married']),
            float(details['dependents']),
            int(details['education']),
            int(details['self_employed']),
            int(details['applicant_income']),
            float(details['coapplicant_income']),
            float(details['loan_amount']),
            float(details['loan_amount_term']),
            int(details['credit_history']),
            int(details['property_area'])
        ]

        # Load model and predict
        model = pickle.load(open('loan_status_classifier.pkl', 'rb'))
        prediction = model.predict([features])[0]
        if prediction == 1:
            output = "Congrats!! You are eligible for the loan."
        else:
            output = "Sorry, you are not eligible for the loan."

    return render_template('predict.html', prediction=output)


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/login')


if __name__ == '__main__':
    app.run(debug=True)
